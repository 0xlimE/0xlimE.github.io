<?php

// Define the path to the image folder
$imageFolder = './images/';

if (isset($_GET['file']) && basename($_GET['file']) == $_GET['file']) {
    $filename = $_GET['file'];
} else {
    echo 'Invalid file requested.';
    exit;
}

// Append the filename to the path of the images folder
$path = $imageFolder . $filename;

// Check if the file exists
if (file_exists($path) && is_readable($path)) {
    // Send appropriate headers
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="'.basename($path).'"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($path));
    // Clear output buffer
    ob_clean();
    // Flush the output buffer
    flush();
    // Read the file and output its content
    readfile($path);
    exit;
} else {
    echo 'File not found.';
}

?>
