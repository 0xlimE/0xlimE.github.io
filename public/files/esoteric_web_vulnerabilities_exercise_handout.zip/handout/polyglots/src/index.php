<?php

$target_dir = "images/";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filename = $_FILES["fileToUpload"]["name"];
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    if ($imageFileType == "gif") {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], strtolower($target_file))) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mimeType = finfo_file($finfo, strtolower($target_file));
            finfo_close($finfo);

            if ($mimeType == "image/gif") {
                echo "The file ". htmlspecialchars(basename($_FILES["fileToUpload"]["name"])). " has been uploaded.";
                echo "<script> setTimeout(function(){window.location.href = \"index.php\";}, 2000); </script>";
            } else {
                unlink(strtolower($target_file));
                echo "Just having the .gif extension is not good enough my friend.";
            }
            
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    } else {
        echo "Sorry, only GIF files are allowed.";
    }
} else if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if(!isset($_GET['user'])){
        header("Location: index.php?user=anonymous");
        die();
    }
    header("Content-Security-Policy: script-src 'self';");
    ?>
    <!DOCTYPE html>
    <html>
        <head>
            <style>
                body {
                    background-color: #F0F0F0;
                    font-family: Arial, sans-serif;
                }
                h1 {
                    text-align: center;
                    color: #333;
                }
                .image-wrapper {
                    border: 1px dotted black;
                    margin-bottom: 15px;
                    padding: 10px;
                }
                .image-wrapper img {
                    max-width: 200px;
                }
                form {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    gap: 10px;
                    margin-top: 20px;
                }
                form input[type='submit'] {
                    padding: 5px 10px;
                    background-color: #008CBA;
                    color: white;
                    border: none;
                    cursor: pointer;
                }
            </style>
        </head>
        <body>
            <h1>Here are the images</h1>
            <?php
            if (isset($_GET['user'])) {
                echo "<p>Welcome, " . $_GET['user'] . "</p>";
            }

            $files = glob($target_dir . "*.{gif}", GLOB_BRACE);
            foreach ($files as $file) {
                ?>
                <div class="image-wrapper">
                    <img src='images/<?php echo htmlspecialchars(basename($file)); ?>' /> 
                    <a href='download.php?file=<?php echo htmlspecialchars(basename($file)); ?>'>download this image</a>
                </div>
                <?php
            }
            ?>
            <form action='index.php' method='post' enctype='multipart/form-data'>
                <label>Select image to upload:</label>
                <input type='file' name='fileToUpload' id='fileToUpload'>
                <input type='submit' value='Upload Image' name='submit'>
            </form>
        </body>
    </html>
    <?php
}
?>
