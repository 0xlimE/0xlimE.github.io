<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #F4F6F8;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column; /* Added */
        }
        form {
            padding: 20px;
            background-color: #FFFFFF;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            margin-bottom: 20px; /* Added */
        }
        form input[type="text"] {
            width: 80%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #DDDDDD;
            border-radius: 5px;
        }
        form input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        form input[type="submit"]:hover {
            background-color: #45a049;
        }
        .result {
            margin-top: 20px; /* Added */
        }
    </style>
</head>
<body>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">
        <label for="value">Enter a room number (0000-9999) to check the tenants flag. </label>
        <input type="text" id="value" name="value">
        <input type="submit" value="Submit">
    </form>
    <div class="result"> <!-- Changed from <p> to <div> -->
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the current time
    $currentTime = time();
    $filename = 'timestamp.txt';

    if (file_exists($filename)) {
        $lastSubmitTime = file_get_contents($filename);
        $elapsedTime = $currentTime - $lastSubmitTime;

        if ($elapsedTime < 300) {
            // Less than 10 minutes have passed
            $remainingTime = 300 - $elapsedTime;
            echo "<br>Please wait $remainingTime seconds before trying again.";
            return;
        }
    }

    // If more than 10 minutes have passed, or if this is the first request,
    // record the current time as the time of the last request.
    file_put_contents($filename, $currentTime);

    // sample dictionary
    $roomnumbers = [
        '2034' => 'FLAG{S0rry_this_flag_is_f4ke}',# Players room
        '1234' => 'FLAG{XXXXXXXXXXX}' # Bots room changed on prod
    ];

    $valueIn = $_POST['value'];
    $value = (string) $valueIn;
    $key =  $roomnumbers[$value];
    if ($key !== NULL) {
        echo "<br>The flag for the tenant in the room '".htmlspecialchars($value)."' is '$key'.";
    } else {
        echo "<br>There does not seem to be any tenants in the room: '".htmlspecialchars($value)."' ";
    }
}
?>
    </div>
</body>
</html>