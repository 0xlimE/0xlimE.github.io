<?php
// Ensure the 'room' parameter exists and is within the correct range
if(isset($_GET['room'])) {
    // Construct the image path
    $imagePath = 'images/' . $_GET['room'][5] . '.jpg';

    // Check if the file exists
    if(file_exists($imagePath)) {
        // Set the correct header for an image file
        header('Content-Type: image/jpeg');

        // Read and output the file content
        readfile($imagePath);
    } else {
        // The file does not exist
        http_response_code(404);
        echo 'Room Image not found. Please specify a valid "room" parameter, like ROOM-XXXX where XXXX = 0000-9999';
    }
} else {
    // Invalid or missing 'room' parameter
    http_response_code(400);
    echo 'Invalid request. Please specify a valid "room" parameter, like ROOM-XXXX where XXXX = 0000-9999';
}
?>
