<?php
$roomnumbers = [
    'AZ921KVM' => 'ROOM-2034',# Players room
    'XXXXXXXX' => 'ROOM-1234' # Bots room - Different on production
];

function validateSecret($inputSecret, $roomnumbers) {
    foreach($roomnumbers as $key => $value) {
        if($inputSecret === $key) {
            return true;
        }
    }
    return false;
}

function getNewSecret($inputSecret, $roomnumbers) {
    if(array_key_exists($inputSecret, $roomnumbers)) {
        return $roomnumbers[$inputSecret];
    }
    return false;
}

$errorMessage = null;
$roomNumber = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if(!isset($_POST['bookingnumber'])) {
        $errorMessage = 'No roomnumber provided.';
    } else {
        $inputSecret = $_POST['bookingnumber'];
        if(validateSecret($inputSecret, $roomnumbers)) {
            setcookie('bookingnumber', $inputSecret, time()+3600); // cookie will expire in 1 hour
            header('Location: /index.php?style=styles.css');
            exit;
        } else {
            $errorMessage = 'Invalid roomnumber.';
        }
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if(isset($_COOKIE['bookingnumber'])) {
        $cookieSecret = $_COOKIE['bookingnumber'];
        if(validateSecret($cookieSecret, $roomnumbers)) {
            $roomNumber = getNewSecret($cookieSecret, $roomnumbers);
        } else {
            $errorMessage = 'Invalid cookie bookingnumber.';
            setcookie('bookingnumber', '', time() - 3600); // remove cookie
            header('Location: /index.php');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Train Car Room Number</title>
    <?php
        if (isset($_GET['style'])) {
            echo '<link rel="stylesheet" type="text/css" href="styles/'.htmlspecialchars($_GET['style']).'">';
        }
        else{
            echo '<link rel="stylesheet" type="text/css" href="styles/styles.css">';
        }
    ?>
</head>
<body>
    <div class="container">
        <?php
        if ($errorMessage) {
            echo '<p class="error">'.htmlspecialchars($errorMessage).'</p>';
        }
        
        if ($roomNumber) {
            echo '<p class="success">Your room number: </p> <a href="/image.php?room='.htmlspecialchars($roomNumber).'" class="roomnumber" >' . htmlspecialchars($roomNumber) . '</a>';
            echo '<br><br><a href="/logout.php?next=index.php"> logout here</a>';
        } else {
            echo '<a href="/admin.php">Admin Check </a>
            <p>Figure out which cabin the admin is in.. Your booking number: AZ921KVM</p>
            <br>
            <form method="post" action="index.php" class="roomnumber-form">
                      Enter Booking Number: <input type="text" name="bookingnumber">
                      <input type="submit">
                  </form>';
        }
        ?>
    </div>
</body>
</html>