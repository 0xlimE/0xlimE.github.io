<?php
// unset the cookie
if (isset($_COOKIE['bookingnumber'])) {
    unset($_COOKIE['bookingnumber']); 
    setcookie('bookingnumber', null, -1, '/'); 
}

// handle the 'next' GET parameter for redirection
if (isset($_GET['next'])) {
    $next = $_GET['next'];
    header("Location: $next");
    exit;
} else {
    // If no redirection page is specified, go to index.php by default
    header('Location: /index.php');
    exit;
}
?>
