from flask import Flask, request, redirect, url_for, session, render_template, jsonify
from urllib.parse import unquote
import sqlite3, os, uuid, hashlib, time, os
from functools import wraps

app = Flask(__name__)

app.secret_key = 'secret_key_here' # Different on prod

def sha256_hexstring(input_string):
    sha256 = hashlib.sha256()
    sha256.update(input_string.encode('utf-8'))
    return sha256.hexdigest()

def fifteen_second_timeout():
    current_time = time.time()
    file_path = "timestamp.txt"

    if os.path.exists(file_path):
        with open(file_path, "r") as f:
            last_time_called = float(f.read())
        if current_time - last_time_called > 15:
            with open(file_path, "w") as f:
                f.write(str(current_time))
            return True
        else:
            return False
    else:
        with open(file_path, "w") as f:
            f.write(str(current_time))
        return True

def initdb(db_path='sqlite3.db'):
    if not os.path.exists(db_path):
        con = sqlite3.connect(db_path)
        cur = con.cursor()
        
        cur.execute('''
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            secret TEXT NOT NULL      
        );
        ''')
        
        con.commit()
        con.close()
        print(f"Database {db_path} initialized.")
    else:
        print(f"Database {db_path} already exists.")

def query_db(query, args=(), one=False):
    con = sqlite3.connect('sqlite3.db')
    cur = con.cursor()
    cur.execute(query, args)
    rv = cur.fetchall()
    cur.close()
    con.commit()
    return (rv[0] if rv else None) if one else rv

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


@app.route('/')
def home():
    return render_template("index.html")

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        secret = request.form['secret']
        
        existing_user = query_db('SELECT * FROM users WHERE username = ?', [username], one=True)
        
        if existing_user:
            return 'Username already exists!'
        else:
            hashed_password = sha256_hexstring(password)
            query_db('INSERT INTO users (username, password, secret) VALUES (?, ?, ?)', (username, hashed_password, secret,))
            return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        hashed_password = sha256_hexstring(password)
        user = query_db('SELECT * FROM users WHERE username = ? AND password = ?', (username, hashed_password), one=True)
        
        if user:
            session['username'] = username
            return redirect("/secret")
        else:
            return 'Invalid username or password'
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/secret')
@login_required
def secret():
    return render_template("secret.html")

@app.route('/profileinfo/<path:text>' , methods=['GET', 'POST'])
@login_required
def profile(text=None):
    username = session['username']
    if text == "update":
        if request.method == 'POST':
            new_secret = request.form.get('new_secret')
            new_password = request.form.get('new_password')
            if new_secret:
                query_db('UPDATE users SET secret = ? WHERE username = ?', (new_secret, username))
            if new_password:
                query_db('UPDATE users SET password = ? WHERE username = ?', (sha256_hexstring(new_password), username))
        return redirect(url_for('me'))
    
    secret = query_db('SELECT secret FROM users WHERE username = ?', (username,), one=True)
    return jsonify({"username": username, "secret": secret[0]})
    
@app.route('/me')
@login_required
def me():
    return render_template("me.html")


if __name__ == '__main__':
    initdb()
    app.run(host='0.0.0.0', port=5000)