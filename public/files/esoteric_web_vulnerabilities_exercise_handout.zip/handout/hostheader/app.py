from flask import Flask, request, render_template, redirect, url_for
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user
from itsdangerous import URLSafeTimedSerializer, SignatureExpired
from flask_mail import Mail, Message
import requests

app = Flask(__name__)
login_manager = LoginManager()
login_manager.init_app(app)

app.config['SECRET_KEY'] = 'avm9o853uayvo5y7aoi7n5vao75'  # provide your secret key here, different on prod
s = URLSafeTimedSerializer('av358ma3m8v5a0v5a0895v')  # for token generation


# Set up Flask-Mail
app.config['MAIL_SERVER'] = 'your_smtp_server'
app.config['MAIL_PORT'] = 'your_port'
app.config['MAIL_USERNAME'] = 'your_email'     # This stuff is not necessary, but I wanted to emulate real email flow
app.config['MAIL_PASSWORD'] = 'your_password'
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False

mail = Mail(app)

# Let's simulate a simple user class and user database
class User(UserMixin):
    def __init__(self, id):
        self.id = id

# Users data
users = {"admin@admin.com": "uingeaiugneaiugneai"}

@login_manager.user_loader
def load_user(user_id):
    return User(user_id)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        if users.get(email) == password:
            user = User(email)
            login_user(user)
            return "Success! FLAG{XXXXXXXXXXXXXXXXXXXX}"
        else:
            return "Failed"
    else:
        return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return 'Logged out!'

@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'POST':
        email = request.form['email']
        if email in users:
            token = s.dumps(email, salt='password-reset')
            msg = Message('Password Reset Request', sender='your_email', recipients=[email])
            link = "http://"+request.host+"/reset?a="+token
            print(link)
            try:
                requests.get(link) # Pretend we are a mail protection bot that visits links to make sure it doesn't contain malware.
            except Exception as e:
                print(e)
            return "The password has been sent to your email"
        else:
            return "Email not found"
    else:
        return render_template('reset-password.html')

@app.route('/reset', methods=['GET', 'POST'])
def reset_with_token():
    token = request.args.get('a')
    try:
        email = s.loads(token, salt='password-reset', max_age=3600)
    except Exception as e:
        return '<h2>SOMETHING IS WRONG</h2>'
    if request.method == 'POST':
        password = request.form['password']
        users[email] = password  # set new password
        return redirect(url_for('login'))
    else:
        return render_template('reset-with-token.html')

if __name__ == '__main__':
    app.run(debug=False,port=5000,host="0.0.0.0")